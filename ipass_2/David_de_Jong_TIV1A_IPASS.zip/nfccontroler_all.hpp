#ifndef NFCCONTROLER_ALL_HPP
#define NFCCONTROLER_ALL_HPP

#include "Mifare_Classic.hpp"
#include "nfccontroler.hpp"
#include "nfccontroler_limited.hpp"
#include "RC522.hpp"

#endif // NFCCONTROLER_ALL_HPP
