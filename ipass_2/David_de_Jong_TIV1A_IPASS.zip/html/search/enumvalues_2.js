var searchData=
[
  ['calccrc',['CalcCRC',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968a3b8f7ce3dcfe31207ffafa7a9226411b',1,'RC522']]],
  ['collreg',['CollReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a55430b019624dd5a86e471c934139089',1,'RC522']]],
  ['comienreg',['ComIEnReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a1845d2c6205cbc45e80752935163eb9b',1,'RC522']]],
  ['comirqreg',['ComIrqReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a1db3ec7619e0d21b8dfb996d4ddeeda4',1,'RC522']]],
  ['commandreg',['CommandReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a11450bdf07b4ea5cc6ad0e81c8d44527',1,'RC522']]],
  ['controlreg',['ControlReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a1148f8c668fcd879ff66e69d3de5ef33',1,'RC522']]],
  ['crcresulth',['CRCResultH',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a15158ec76a6b7554960616739a09510c',1,'RC522']]],
  ['crcresultl',['CRCResultL',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431abb777b58a054709c49fb8af8dd20dd29',1,'RC522']]],
  ['cwgspreg',['CWGsPReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a490ac2ae01c21e11e5179a310a62dc5f',1,'RC522']]]
];
