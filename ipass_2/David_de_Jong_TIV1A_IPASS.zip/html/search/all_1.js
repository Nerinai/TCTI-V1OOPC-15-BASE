var searchData=
[
  ['bitframingreg',['BitFramingReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a3f2ed081137698e3d6c2c11dfd5129e4',1,'RC522']]]
];
