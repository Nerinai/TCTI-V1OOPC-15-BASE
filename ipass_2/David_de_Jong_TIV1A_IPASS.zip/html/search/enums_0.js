var searchData=
[
  ['cmd',['CMD',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968',1,'RC522']]]
];
