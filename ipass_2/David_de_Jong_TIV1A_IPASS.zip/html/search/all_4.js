var searchData=
[
  ['errorreg',['ErrorReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431aa66722964ad21187ec3874c513c04718',1,'RC522']]]
];
