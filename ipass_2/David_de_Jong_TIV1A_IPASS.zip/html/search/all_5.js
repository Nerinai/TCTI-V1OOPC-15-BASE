var searchData=
[
  ['fifodatareg',['FIFODataReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a8ef9fd587fd6567688f467a414073432',1,'RC522']]],
  ['fifolevelreg',['FIFOLevelReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a5c1d7d189a703ace5301ce9abfa9faf9',1,'RC522']]]
];
