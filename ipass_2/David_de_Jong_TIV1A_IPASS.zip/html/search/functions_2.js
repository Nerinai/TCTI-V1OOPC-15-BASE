var searchData=
[
  ['getantennagain',['getAntennaGain',['../classnfccontroler.html#a99c9451d564a62c525925f8ca79a9d1e',1,'nfccontroler::getAntennaGain()'],['../class_r_c522.html#a08a908f30b995446c40b0ba89cf7a40c',1,'RC522::getAntennaGain()']]]
];
