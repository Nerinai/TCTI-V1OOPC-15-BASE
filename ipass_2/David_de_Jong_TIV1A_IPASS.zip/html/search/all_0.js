var searchData=
[
  ['analogtestreg',['AnalogTestReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431aa62f2f135975e5ec12aa3c84947483d8',1,'RC522']]],
  ['antennaoff',['antennaOff',['../classnfccontroler.html#a0d8180637c367d223d437a506a641bae',1,'nfccontroler::antennaOff()'],['../class_r_c522.html#a21cce592f19fdbdc440bfec6045eb5ac',1,'RC522::antennaOff()']]],
  ['antennaon',['antennaOn',['../classnfccontroler.html#a161af319560127b028504add241a8bc6',1,'nfccontroler::antennaOn()'],['../class_r_c522.html#ae4dbd838876dbd901d811af06e72a448',1,'RC522::antennaOn()']]],
  ['authenticatesector',['authenticateSector',['../class_mifare___classic.html#a2e79d1842e44e1600f59fdfba4b22470',1,'Mifare_Classic::authenticateSector()'],['../classnfccontroler__limited.html#a4eec4cf702e4c0062c33657e81a2069f',1,'nfccontroler_limited::authenticateSector()'],['../class_r_c522.html#a84000801a44a02cf59601400b809f5a3',1,'RC522::authenticateSector()']]],
  ['authwitha',['AuthwithA',['../class_r_c522.html#a3dcadf9d9544de3a436a34018dea676ba1e7b8f8d328f24fb6773e9656f1ed5be',1,'RC522']]],
  ['authwithb',['AuthwithB',['../class_r_c522.html#a3dcadf9d9544de3a436a34018dea676baceae6de53afe58721569fa62b289a3cd',1,'RC522']]],
  ['autotestreg',['AutoTestReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a9ff9256cf4bb95b3434218c6eec62cb1',1,'RC522']]]
];
