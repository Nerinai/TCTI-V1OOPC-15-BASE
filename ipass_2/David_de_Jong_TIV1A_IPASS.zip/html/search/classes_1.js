var searchData=
[
  ['nfccontroler',['nfccontroler',['../classnfccontroler.html',1,'']]],
  ['nfccontroler_5flimited',['nfccontroler_limited',['../classnfccontroler__limited.html',1,'']]]
];
