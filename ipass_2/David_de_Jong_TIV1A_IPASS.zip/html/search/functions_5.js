var searchData=
[
  ['rc522',['RC522',['../class_r_c522.html#afe9b5dc493a0768dae120a869dc5af12',1,'RC522']]],
  ['readblock',['readBlock',['../class_mifare___classic.html#a6401f278760213b5c53e3c41aa5b0c98',1,'Mifare_Classic::readBlock()'],['../classnfccontroler__limited.html#a5a8f607de57023a90962f6ac4fa2b5f1',1,'nfccontroler_limited::readBlock()'],['../class_r_c522.html#a4a9843ee47bd24f6446bb8c327411076',1,'RC522::readBlock()']]],
  ['readfifo',['readFIFO',['../classnfccontroler.html#afcab6129cc6c97452f998c46e8088d01',1,'nfccontroler::readFIFO(void)=0'],['../classnfccontroler.html#ac1b18db7bd72cf1a2d6cd995ee3919cb',1,'nfccontroler::readFIFO(byte *output)=0'],['../class_r_c522.html#a78c18a8805798cda24ed7c35af43f6c3',1,'RC522::readFIFO(void) override'],['../class_r_c522.html#a2e5ac8769707047e4064200d1829927c',1,'RC522::readFIFO(byte *output) override']]],
  ['readregister',['readRegister',['../classnfccontroler.html#aaf3c333dece31c91679bb60a58bf1ef9',1,'nfccontroler::readRegister()'],['../class_r_c522.html#ad824f9c57546a79af49cdd9da960275b',1,'RC522::readRegister(Reg a)'],['../class_r_c522.html#a5de4e5d16b9d54c859f6db3de68c8147',1,'RC522::readRegister(byte registerAddress) override']]],
  ['readsector',['readSector',['../class_mifare___classic.html#a7caca9ec9a0cdc116f8056753ecc438c',1,'Mifare_Classic::readSector()'],['../classnfccontroler__limited.html#a70d6de379a501af2272da775c5d27c9e',1,'nfccontroler_limited::readSector()'],['../class_r_c522.html#a6c6409ef5f4385e9d1efac5b2f9caed0',1,'RC522::readSector()']]]
];
