var searchData=
[
  ['reg',['Reg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431',1,'RC522']]]
];
