var searchData=
[
  ['calculatecrc',['calculateCRC',['../classnfccontroler.html#a0a04b877e9de8677b5bfe9e28424cbca',1,'nfccontroler::calculateCRC()'],['../class_r_c522.html#a97d66d97883cf728889098e4a2522f27',1,'RC522::calculateCRC()']]],
  ['checkerroandirq',['checkErroAndIrq',['../class_mifare___classic.html#a9377d560c083320ad3b605df464a29e4',1,'Mifare_Classic::checkErroAndIrq()'],['../classnfccontroler__limited.html#a97f279888626df09059338d149a3dcf1',1,'nfccontroler_limited::checkErroAndIrq()'],['../class_r_c522.html#a8797a7dcb6e4a7e3e30bf476ef47e894',1,'RC522::checkErroAndIrq()']]],
  ['clearregistermask',['clearRegisterMask',['../classnfccontroler.html#a02cfe73ff95bd107f2020ada91ac7af4',1,'nfccontroler::clearRegisterMask()'],['../class_r_c522.html#ac8dda7d6495cd0e79815ba771012b1b4',1,'RC522::clearRegisterMask()']]],
  ['communicatenfc',['communicateNFC',['../classnfccontroler.html#a742e67e43b865074c4f23fb6c133cdd7',1,'nfccontroler::communicateNFC()'],['../class_r_c522.html#aa8ec37f7914b3aa1e3866dda7e08063f',1,'RC522::communicateNFC()']]]
];
