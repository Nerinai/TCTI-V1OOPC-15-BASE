var searchData=
[
  ['calccrc',['CalcCRC',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968a3b8f7ce3dcfe31207ffafa7a9226411b',1,'RC522']]],
  ['calculatecrc',['calculateCRC',['../classnfccontroler.html#a0a04b877e9de8677b5bfe9e28424cbca',1,'nfccontroler::calculateCRC()'],['../class_r_c522.html#a97d66d97883cf728889098e4a2522f27',1,'RC522::calculateCRC()']]],
  ['checkerroandirq',['checkErroAndIrq',['../class_mifare___classic.html#a9377d560c083320ad3b605df464a29e4',1,'Mifare_Classic::checkErroAndIrq()'],['../classnfccontroler__limited.html#a97f279888626df09059338d149a3dcf1',1,'nfccontroler_limited::checkErroAndIrq()'],['../class_r_c522.html#a8797a7dcb6e4a7e3e30bf476ef47e894',1,'RC522::checkErroAndIrq()']]],
  ['clearregistermask',['clearRegisterMask',['../classnfccontroler.html#a02cfe73ff95bd107f2020ada91ac7af4',1,'nfccontroler::clearRegisterMask()'],['../class_r_c522.html#ac8dda7d6495cd0e79815ba771012b1b4',1,'RC522::clearRegisterMask()']]],
  ['cmd',['CMD',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968',1,'RC522']]],
  ['collreg',['CollReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a55430b019624dd5a86e471c934139089',1,'RC522']]],
  ['comienreg',['ComIEnReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a1845d2c6205cbc45e80752935163eb9b',1,'RC522']]],
  ['comirqreg',['ComIrqReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a1db3ec7619e0d21b8dfb996d4ddeeda4',1,'RC522']]],
  ['commandreg',['CommandReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a11450bdf07b4ea5cc6ad0e81c8d44527',1,'RC522']]],
  ['communicatenfc',['communicateNFC',['../classnfccontroler.html#a742e67e43b865074c4f23fb6c133cdd7',1,'nfccontroler::communicateNFC()'],['../class_r_c522.html#aa8ec37f7914b3aa1e3866dda7e08063f',1,'RC522::communicateNFC()']]],
  ['controlreg',['ControlReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a1148f8c668fcd879ff66e69d3de5ef33',1,'RC522']]],
  ['crcresulth',['CRCResultH',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a15158ec76a6b7554960616739a09510c',1,'RC522']]],
  ['crcresultl',['CRCResultL',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431abb777b58a054709c49fb8af8dd20dd29',1,'RC522']]],
  ['cwgspreg',['CWGsPReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a490ac2ae01c21e11e5179a310a62dc5f',1,'RC522']]]
];
