var searchData=
[
  ['keytype',['Keytype',['../class_r_c522.html#a3dcadf9d9544de3a436a34018dea676b',1,'RC522']]]
];
