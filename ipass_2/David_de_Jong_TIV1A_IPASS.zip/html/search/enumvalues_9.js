var searchData=
[
  ['nocmdchange',['NoCmdChange',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968a523f1f3bda25793f86274cedffbaf328',1,'RC522']]]
];
