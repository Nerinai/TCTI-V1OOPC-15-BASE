var searchData=
[
  ['getantennagain',['getAntennaGain',['../classnfccontroler.html#a99c9451d564a62c525925f8ca79a9d1e',1,'nfccontroler::getAntennaGain()'],['../class_r_c522.html#a08a908f30b995446c40b0ba89cf7a40c',1,'RC522::getAntennaGain()']]],
  ['gsnreg',['GsNReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a2512f36505f04da7da175efa353a8ade',1,'RC522']]]
];
