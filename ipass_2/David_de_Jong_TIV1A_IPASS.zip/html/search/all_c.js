var searchData=
[
  ['selectcard',['selectCard',['../class_mifare___classic.html#aaa549c00df8619bb2f5a96bba093f005',1,'Mifare_Classic::selectCard()'],['../classnfccontroler__limited.html#a195f3de8d1529e00998f60ddf8058f6b',1,'nfccontroler_limited::selectCard()'],['../class_r_c522.html#a2b41c31a04a41b6098945b0fddcf1476',1,'RC522::selectCard()']]],
  ['selftest',['selfTest',['../classnfccontroler.html#adf8ddf5ba68a3d6689f5cdc15e294151',1,'nfccontroler::selfTest()'],['../class_r_c522.html#ad21aeb49627a3da99d214798886267b9',1,'RC522::selfTest()']]],
  ['serialspeedreg',['SerialSpeedReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431ab5f45bb3dfaf437ce8afb34039d97696',1,'RC522']]],
  ['setantennagain',['setAntennaGain',['../classnfccontroler.html#ae76958998275b8e4acc04c1fe61998e5',1,'nfccontroler::setAntennaGain()'],['../class_r_c522.html#aa5a6532f6ef2de5ca9236567ff88d346',1,'RC522::setAntennaGain()']]],
  ['setregistermask',['setRegisterMask',['../classnfccontroler.html#af35dd99e72c2321c50dec98529e04a83',1,'nfccontroler::setRegisterMask()'],['../class_r_c522.html#a14cc49cb3afd67164ebceffdb38dd605',1,'RC522::setRegisterMask()']]],
  ['softreset',['SoftReset',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968a109e0d0bf2b42091e997ddc4d49bab8d',1,'RC522']]],
  ['status1reg',['Status1Reg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a10ec4b900ce861cd1e1d8be2cd914f13',1,'RC522']]],
  ['status2reg',['Status2Reg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a4c81dff53f5608e5e4eb93616699e953',1,'RC522']]]
];
