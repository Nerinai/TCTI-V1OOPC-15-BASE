var searchData=
[
  ['idle',['Idle',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968ae599161956d626eda4cb0a5ffb85271c',1,'RC522']]]
];
