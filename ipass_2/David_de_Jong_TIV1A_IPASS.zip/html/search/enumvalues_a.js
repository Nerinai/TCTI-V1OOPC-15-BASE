var searchData=
[
  ['randid',['RandId',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968a0f15bdc78a60f6b39a945102fb09e119',1,'RC522']]],
  ['recieve',['Recieve',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968aac3e7dbb9d8e868b27d027b446205fb7',1,'RC522']]],
  ['rfcfgreg',['RFCfgReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a2e8033091c806e68d5715040aa056a03',1,'RC522']]],
  ['rxmodereg',['RxModeReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a4130d37867b7dd3c1b02f59bf6959cb1',1,'RC522']]],
  ['rxselreg',['RxSelReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a52763be9e2839e0840ed522b6694158e',1,'RC522']]],
  ['rxtresholdreg',['RxTresholdReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431ad301eadb31d2c942b737d4f2d8922e66',1,'RC522']]]
];
