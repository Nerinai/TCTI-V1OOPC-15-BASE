var searchData=
[
  ['demodreg',['DemodReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431adf65e1aa787f21e363c7836a6472f36c',1,'RC522']]],
  ['divienreg',['DivIEnReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431aab1dc60f00e0544f9497198c1d3fae89',1,'RC522']]],
  ['divirqreg',['DivIrqReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a7892fc58b473802b634afaefd31bbe00',1,'RC522']]]
];
