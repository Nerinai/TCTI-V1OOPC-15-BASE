var searchData=
[
  ['initchip',['initChip',['../classnfccontroler.html#a4f5a22e5f25f56abe26ed0034a296135',1,'nfccontroler::initChip()'],['../class_r_c522.html#a87733717cd499f3d51ad9034f78cda9d',1,'RC522::initChip()']]],
  ['iscard',['isCard',['../class_mifare___classic.html#ae02721fc8b9268e93778fdc47d06d162',1,'Mifare_Classic::isCard()'],['../classnfccontroler__limited.html#ae1e689d34ba8bcd933c696b3f852dad6',1,'nfccontroler_limited::isCard()'],['../class_r_c522.html#a6cef2c82c923eeed59bd3cb5e7a42090',1,'RC522::isCard()']]]
];
