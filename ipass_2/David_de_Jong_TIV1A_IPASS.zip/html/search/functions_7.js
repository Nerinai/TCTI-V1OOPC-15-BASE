var searchData=
[
  ['trancievedata',['trancieveData',['../class_mifare___classic.html#ac35863ec691f0a118156bea44c4cd7a7',1,'Mifare_Classic::trancieveData()'],['../classnfccontroler__limited.html#a35a7cc1d586511b6a35294bc234530e0',1,'nfccontroler_limited::trancieveData()'],['../class_r_c522.html#a8204221660aea7c393eb49340d29876a',1,'RC522::trancieveData()']]]
];
