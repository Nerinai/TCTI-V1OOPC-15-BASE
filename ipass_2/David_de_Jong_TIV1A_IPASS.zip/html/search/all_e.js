var searchData=
[
  ['versionreg',['VersionReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a4c239ecd6090284f00aaf1770acca869',1,'RC522']]]
];
