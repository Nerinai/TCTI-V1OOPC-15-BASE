var searchData=
[
  ['waterlevelreg',['WaterLevelReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a9ee43b33a46d131d74a9d7c7e458a010',1,'RC522']]],
  ['writeblock',['writeBlock',['../class_mifare___classic.html#adb793958d3f2601d336165e383a456f6',1,'Mifare_Classic::writeBlock()'],['../classnfccontroler__limited.html#aeeeb82c8b45881239c7b2d9b4bce9ef5',1,'nfccontroler_limited::writeBlock()'],['../class_r_c522.html#a42c197d61571667a97176f7294b0a8dd',1,'RC522::writeBlock()']]],
  ['writefifo',['writeFIFO',['../classnfccontroler.html#aef681b8f4a4a7d982c30ee2d9e8124da',1,'nfccontroler::writeFIFO(const byte value)=0'],['../classnfccontroler.html#a5e9de8b00b7bea62fe4f422a898018a9',1,'nfccontroler::writeFIFO(const int byte_amount, const byte *data)=0'],['../class_r_c522.html#a3923806b946c8e35465faca39095fe05',1,'RC522::writeFIFO(const byte value) override'],['../class_r_c522.html#ac72080585e07afd1d51fbb4dbc6a8e58',1,'RC522::writeFIFO(const int byte_amount, const byte *data) override']]],
  ['writeregister',['writeRegister',['../classnfccontroler.html#a0ea9c75e4dbe9dbeb81b49cac5e382db',1,'nfccontroler::writeRegister()'],['../class_r_c522.html#a8860f482253b39808658bf5cdbbe342d',1,'RC522::writeRegister()']]],
  ['writesector',['writeSector',['../class_mifare___classic.html#a127803e07c148fe8d447a00e28be4a90',1,'Mifare_Classic::writeSector()'],['../classnfccontroler__limited.html#ad4d31d46ee21766eaaa0a4f1916cc8d8',1,'nfccontroler_limited::writeSector()'],['../class_r_c522.html#a11e060e686331017873edd877c3255cd',1,'RC522::writeSector()']]]
];
