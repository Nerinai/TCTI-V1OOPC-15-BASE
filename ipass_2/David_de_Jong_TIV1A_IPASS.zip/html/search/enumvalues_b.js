var searchData=
[
  ['serialspeedreg',['SerialSpeedReg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431ab5f45bb3dfaf437ce8afb34039d97696',1,'RC522']]],
  ['softreset',['SoftReset',['../class_r_c522.html#a8d2b2b09cb1978142f8c31b89049d968a109e0d0bf2b42091e997ddc4d49bab8d',1,'RC522']]],
  ['status1reg',['Status1Reg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a10ec4b900ce861cd1e1d8be2cd914f13',1,'RC522']]],
  ['status2reg',['Status2Reg',['../class_r_c522.html#a7bf90c1bc00e047a687a30948f18a431a4c81dff53f5608e5e4eb93616699e953',1,'RC522']]]
];
